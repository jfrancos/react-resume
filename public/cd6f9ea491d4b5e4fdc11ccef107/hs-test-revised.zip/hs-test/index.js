const fetch = require("node-fetch");
var _ = require("lodash");

const getURL =
  "https://candidate.hubteam.com/candidateTest/v3/problem/dataset?userKey=cd6f9ea491d4b5e4fdc11ccef107";

const postURL =
  "https://candidate.hubteam.com/candidateTest/v3/problem/result?userKey=cd6f9ea491d4b5e4fdc11ccef107";

const showStatus = (response) => {
  console.log(response.status, response.statusText, "\n");
};

const get = async () => {
  const response = await fetch(getURL);
  showStatus(response);
  return response.json();
};

const post = async (data) => {
  response = await fetch(postURL, {
    method: "POST",
    body: JSON.stringify(data),
    headers: {
      "Content-Type": "application/json",
    },
  });
  showStatus(response);
};

const countrySet = new Set();
const datesByCountry = {};
const countries = [];

const pickDate = (dates) => {
  if (dates.length === 0) {
    return null;
  }
  const counts = {};
  let largest = 0;
  dates.forEach((date) => {
    if (counts[date] === undefined) {
      counts[date] = 0;
    }
    counts[date]++;
    if (counts[date] > largest) {
      largest = counts[date];
    }
  });
  const largestDates = [];
  Object.entries(counts).forEach(([date, count]) => {
    if (count === largest) {
      largestDates.push(date);
    }
  });
  largestDates.sort();
  return largestDates[0];
};

const main = async () => {
  const { partners } = await get();

  partners.forEach((partner) => {
    countrySet.add(partner.country);
    if (datesByCountry[partner.country] === undefined) {
      datesByCountry[partner.country] = [];
    }

    const feasibleDates = partner.availableDates.filter((dateString, index, dates) => {
      const date = new Date(dateString);
      date.setDate(date.getDate() + 1);
      const nextDate = date.toISOString().slice(0, 10);
      return (
        index < partner.availableDates.length - 2 &&
        dates[index + 1] === nextDate
      );
    });
    datesByCountry[partner.country] = [
      ...datesByCountry[partner.country],
      ...feasibleDates,
    ];
  });

  Object.entries(datesByCountry).forEach(([name, dates]) => {
    const startDate = pickDate(dates);
    const attendees = _.filter(partners, (partner) => {
      return (
        partner.country === name && partner.availableDates.includes(startDate)
      );
    }).map((attendee) => attendee.email);
    const attendeeCount = attendees.length;
    countries.push({
      attendeeCount,
      name,
      attendees,
      startDate,
    });
  });
  post({ countries });
};

main();
